package test;
import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import pojo.Adresse;
import pojo.Client;
import pojo.Detail;
import pojo.DetailId;
import pojo.Facture;
import pojo.Pays;
import pojo.Personne;
import pojo.Produit;


public class TesterHibernateUtil3 {

	public static void main(String[] args) {
		
		
		Session session = null;
		session = HibernateUtil.instance().openSession();
		
		Transaction tx = null;
		try{
			tx = session.beginTransaction(); //commencer la transaction
			// les op�rations avec Hibernate
			// 1 Recuperer un client
			Client client = (Client) session.get(Client.class, new Integer(1));
			// 2 Recuperer un produit
			Produit produit = (Produit) session.get(Produit.class, new Integer(1));
			// Creer une facture
			Facture facture = new Facture();
			facture.setClient(client);
			facture.setDateFacturation(new Date());
			facture.setModePaiement('c');
			facture.setMontantTotal(0.00);
			facture.setNrFacture("5846645454");
			facture.setPayer((byte)0);
			facture.setTauxTva(0.21f);
			facture.setTypeAchat('c');
			session.persist(facture); // On a pas besoin de relier au vendeur ou a une adresse de livraison
			
			// Modifier la classe DetailId et Detail
			// C'est l'objet qui va g�rer la correspondance avec la table intermediaire 
			Detail detail = new Detail();
			
			// Creer un detailId
			DetailId detailId = new DetailId();
			detailId.setIdProduit(produit.getIdProduit());
			detailId.setIdFacture(facture.getIdFacture());
			
			// On va entrer les parametres pour la classe detail
			detail.setId(detailId);
			detail.setQuantite(5);
			detail.setProduit(produit);
			detail.setFacture(facture);
			detail.setPrixHtva(produit.getPrixHtva());
			session.persist(detail);
			
			produit.decrementerProduit(detail.getQuantite());
			
			// On va associer l'objet detail a la set detail de facture
			facture.getDetails().add(detail);
			
			double montantTotal = 0.00;
			for (Detail d : facture.getDetails()){
				montantTotal += (d.getPrixHtva()) * d.getQuantite() * (1 + facture.getTauxTva());
			}
			facture.setMontantTotal(montantTotal);
			
			// Liberer le tampon
			session.flush();
			
			tx.commit();
			System.out.println("pas de probl�me de mapping");
		}
		catch (HibernateException e) {
			if (tx != null) tx.rollback();
			e.printStackTrace(); 
		}
		finally {
			session.close(); 
		}
		
	}

}
