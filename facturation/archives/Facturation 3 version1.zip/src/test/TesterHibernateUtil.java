package test;
import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import pojo.Adresse;
import pojo.Client;
import pojo.Pays;
import pojo.Personne;


public class TesterHibernateUtil {

	public static void main(String[] args) {
		
		Session session = null;
		session = HibernateUtil.instance().openSession();
		
		Transaction tx = null;
		try{
			tx = session.beginTransaction(); //commencer la transaction
			// les op�rations avec Hibernate
			// Encoder un pays et le rendre persistant
			Pays pays = new Pays("France");
			session.persist(pays);
			
			// Encoder une adresse et le rendre persistant
			Adresse adresse = new Adresse(pays, "Rue des Perdus", "15", "7000", "Mons");
			session.persist(adresse);
			
			// Encoder un client et le rendre persistant
			Personne personne = new Personne("Mpira", "Abdallah", "mpira.abdallah@gmail.com", "0477121517");
			session.persist(personne);
			Client client = new Client(personne, adresse, new Date(),
					'H', 0.1f, "Saga Africa", "BE0507096543");
			session.persist(client);
			
			tx.commit(); // Mettre physiquement les objets cr��s dans la base de donn�es
			System.out.println("pas de probl�me de mapping");
		}
		catch (HibernateException e) {
			if (tx != null) tx.rollback(); // On lui dit de ne pas tenir compte des op�rations effectu�es
			e.printStackTrace(); 
		}
		finally {
			session.close(); 
		}
		
	}

}
