package test;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import pojo.Categorie;
import pojo.Composite;
import pojo.CompositeId;
import pojo.Produit;


public class TesterHibernateUtil4 {

	public static void main(String[] args) {
		
		
		Session session = null;
		session = HibernateUtil.instance().openSession();
		
		Transaction tx = null;
		try{
			tx = session.beginTransaction(); //commencer la transaction
			
			// les op�rations avec Hibernate
			// Encoder les produits simples
			// Encoder les 3 cat�gories
			Categorie c1 = new Categorie("Hard Disk");
			session.persist(c1);
			Categorie c2 = new Categorie("Mother Board");
			session.persist(c2);
			Categorie c3 = new Categorie("DeskTop");
			session.persist(c3);
			
			// Creer les produits simples
			Produit ps1 = new Produit(c1, "HD1T", "SA151455", 100, "Tourne bien", "image\\hd.jpg", 100, 's');
			session.persist(ps1);
			Produit ps2 = new Produit(c2, "MB", "SA154955", 200, "Toute jolie", "image\\mb.jpg", 100, 's');
			session.persist(ps2);
			
			// Creer le produit composite
			Produit pc1 = new Produit(c3, "Mini Tower", "SA291455", 0, "Tourne bien", "image\\minitower.jpg", 0, 'c');
			session.persist(pc1);
			
			// Creation du premier composite
			Composite compo1 = new Composite();
			CompositeId cpId1 = new CompositeId();
			cpId1.setIdProduit(pc1.getIdProduit());
			cpId1.setIdSousProduit(ps1.getIdProduit());
			compo1.setId(cpId1);
			compo1.setQuantite(2);
			compo1.setProduitByIdProduit(pc1);
			compo1.setProduitByIdSousProduit(ps1);
			session.persist(compo1);
			
			// Creation du deuxieme composite
			Composite compo2 = new Composite();
			CompositeId cpId2 = new CompositeId();
			cpId2.setIdProduit(pc1.getIdProduit());
			cpId2.setIdSousProduit(ps2.getIdProduit());
			compo2.setId(cpId2);
			compo2.setQuantite(1);
			compo2.setProduitByIdProduit(pc1);
			compo2.setProduitByIdSousProduit(ps2);
			session.persist(compo2);
			
			// On ajoute les composites a la Set du produit
			pc1.getCompositesForIdSousProduit().add(compo1);
			pc1.getCompositesForIdSousProduit().add(compo2);
			
			// On cr�e 5 pieces DeskTop
			pc1.setStock(5);
			// On decremente le stock en fonction du nombre de desktop cr��
			// compo1.getQuantite() <-- quantite necessaire pour une tour multipli� par 5
			ps1.decrementerProduit(compo1.getQuantite() * pc1.getStock());
			ps2.decrementerProduit(compo2.getQuantite() * pc1.getStock());
			
			//Calcul du montant d'une tour
			double montantHTVATour = 0.00;
			for (Composite cp : pc1.getCompositesForIdSousProduit()){
				montantHTVATour += cp.getQuantite() * cp.getProduitByIdSousProduit().getPrixHtva();
			}
			
			// On rentre la valeur dans la produit composite
			pc1.setPrixHtva(montantHTVATour);
			
			// Liberation du tampon			
			session.flush();
			
			tx.commit();
			System.out.println("pas de probl�me de mapping");
		}
		catch (HibernateException e) {
			if (tx != null) tx.rollback();
			e.printStackTrace(); 
		}
		finally {
			session.close(); 
		}
		
	}

}
